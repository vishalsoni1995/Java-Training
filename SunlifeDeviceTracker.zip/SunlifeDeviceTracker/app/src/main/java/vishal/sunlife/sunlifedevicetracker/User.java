package vishal.sunlife.sunlifedevicetracker;

/**
 * Created by HKT5 on 23-11-2017.
 */

public class User {

    private String name;
    private int employeeId;

    public String getName() {
        return name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public User(String name, int employeeId) {
        this.name = name;
        this.employeeId = employeeId;
    }
}
