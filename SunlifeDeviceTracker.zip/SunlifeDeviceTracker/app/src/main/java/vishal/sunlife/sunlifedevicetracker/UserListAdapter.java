package vishal.sunlife.sunlifedevicetracker;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by HKT5 on 23-11-2017.
 */

public class UserListAdapter extends ArrayAdapter<User> {

    private List<User> userList;

    public UserListAdapter(Context context, int resource,List<User> users) {
        super(context, resource, users);
        userList = users;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView==null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.user_list_item,parent,false);
        }

        User user = userList.get(position);
        TextView name = (TextView) convertView.findViewById(R.id.nameText);
        TextView id = (TextView) convertView.findViewById(R.id.employeeid);
         name.setText(user.getName());
         id.setText(String.valueOf(user.getEmployeeId()));
        return convertView;
    }
}
