package vishal.sunlife.sunlifedevicetracker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by HKT5 on 23-11-2017.
 */

public final class DataProvider {
    public static List<User> userList = new ArrayList<>();

    static {

        addProduct("Vishal",
                1821008);

        addProduct("Rahul",
                182145);

        addProduct("Aman",
                182135);

        addProduct("Deepanshu",
                182134);

        addProduct("Uday",
                182345);

        addProduct("Ankit",
                182655);

        addProduct("Raman",
                182355);

        addProduct("Himanshu",
                182355);

        addProduct("Varun",
                187855);

        addProduct("Sherin",
                165455);

        addProduct("Seema",
                183455);

        addProduct("Ritu",
                134555);

        addProduct("Ghuncha",
                185655);



    }

    private static void addProduct(String name, int employeeId) {
        User item = new User(name, employeeId);
        userList.add(item);
    }


    public static List<String> getUserNames() {
        List<String> list = new ArrayList<>();
        for (User user : userList) {

            list.add(user.getName());

        }
        return list;
    }


    public static List<Integer> getEmployeeId() {
        List<Integer> list = new ArrayList<>();
        for (User user : userList) {

            list.add(user.getEmployeeId());
        }
        return list;
    }
}
